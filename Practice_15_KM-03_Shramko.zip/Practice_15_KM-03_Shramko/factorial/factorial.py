import math
def fact(x):
    xFact = math.factorial(x)
    return xFact