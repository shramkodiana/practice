import math
def root2(i):
    if i > 0:
        return math.sqrt(i)
def root3(i):
    if i > 0:
        return pow(i, 1/3)