def exp2(i):
    answ = i**2
    return answ
def exp3(i):
    ans = i**3
    return ans