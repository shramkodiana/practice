import math
def log(a,b):
    return math.log(b, a)
def ln(b):
    return math.log(b)
def lg(b):
    return math.log10(b)
