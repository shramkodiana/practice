from factorial import factorial
from exp_root import exponentiation
from exp_root import root
from logarithm import logarithm
def menu():
    print("Якщо вам потрібно:")
    print("Знайти факторіал числа натисніть 1")
    print('Піднести число до другого степеня натисніть 2')
    print("Піднести число до третього степеня натисніть 3")
    print('Отримати квадратний корінь числа натисніть 4')
    print("Отримати корінь третього степеня з числа натисніть 5")
    print("Отримати логарифм числа по основі іншого числа натисніть 6")
    print("Отримати натуральний логарифм числа натисніть 7")
    print("Отримати десятковий логарифм числа натисніть 8")
    userAsk = input('Яку функцію бажаєте обрати?')
    if userAsk == "1":
        try:
            x = int(input("Введіть натуральне число:"))
            if x > 0 and isinstance(x, int):
                print("Відповідь:", factorial.fact(x))
            else:
                print("Помилка! Число має бути натуральним")
        except ValueError:
            print("Помилка! Необхідно ввести число")
    elif userAsk == "2":
        try:
            i = int(input("Введіть число:"))
            print("Відповідь:", exponentiation.exp2(i))
        except ValueError:
            print("Помилка! Необхідно ввести число")
    elif userAsk == "3":
        try:
            i = int(input("Введіть число:"))
            print("Відповідь:", exponentiation.exp3(i))
        except ValueError:
            print("Помилка! Необхідно ввести число")
    elif userAsk == "4":
        try:
            i = int(input("Введіть додатне число:"))
            if i > 0:
                print("Відповідь:", root.root2(i))
            else:
                print("Помилка! Ви ввели не додатне число")
        except ValueError:
            print("Помилка! Необхідно ввести число")
    elif userAsk == "5":
        try:
            i = int(input("Введіть додатне число:"))
            if i > 0:
                print("Відповідь:", root.root3(i))
            else:
                print("Помилка! Ви ввели не додатне число")
        except ValueError:
            print("Помилка! Необхідно ввести число")
    elif userAsk == "6":
        try:
            a = float(input("Введіть основу логарифму(число має бути додатним та не дорівнювати 1):"))
            b = float(input("Введіть число(число має бути додатним):"))
            if a > 0 and a != 1 and b > 0:
                print("Відповідь:", logarithm.log(b,a))
            print("Помилка! Число не задовольняє умові")
        except ValueError:
            print("Помилка! Необхідно ввести число")
    elif userAsk == "7":
        try:
            b = float(input("Введіть число додатне:"))
            if b > 0:
                print("Відповідь:", logarithm.ln(b))
            else:
                print("Помилка! Ви ввели не додатне число")
        except ValueError:
            print("Помилка! Необхідно ввести число")
    elif userAsk == "8":
        try:
            b = float(input("Введіть число додатне:"))
            if b > 0:
                print("Відповідь:", logarithm.lg(b))
            else:
                print("Помилка! Ви ввели не додатне число")
        except ValueError:
            print("Помилка! Необхідно ввести число")
menu()